# Surgir Entregas — plugin de prueba SURGIR

Plugin de **prueba** de SURGIR para **vender ítems y gestionar entregas**
dentro de servidores Minecraft (Paper / Spigot / Folia). Gratis (0 pesos).

## Instalación

1. Descarga `surgir-entregas.zip` y descomprímelo.
2. Copia `SurgirEntregas.jar` (o la carpeta compilada) en la carpeta `plugins/`
   de tu servidor.
3. Reinicia el servidor.
4. Se genera automáticamente el archivo `plugins/SurgirEntregas/config.yml`.
5. Edita ese `config.yml` con tus ítems, precios y mensajes, y recarga con
   `/entrega reload`.

> Este paquete es una **demo** del plugin: los archivos fuente y la
> configuración se incluyen para que puedas probar y personalizar. Compila con
> `mvn package` o integra la carpeta `src/` a tu proyecto Spigot/Paper.

## Uso básico

| Comando            | Qué hace                                   |
| ------------------ | ------------------------------------------ |
| `/entrega help`    | Muestra la ayuda                           |
| `/entrega shop`    | Abre el menú de venta de ítems             |
| `/entrega buy <id>`| Compra un ítem por su ID                   |
| `/entrega reload`  | Recarga la configuración (requiere permiso)|

## Permisos

- `surgir.entregas.use` — usar los comandos básicos (por defecto: todos).
- `surgir.entregas.buy` — comprar ítems (por defecto: todos).
- `surgir.entregas.admin` — `/entrega reload` y configuración (por defecto: op).

## Configuración rápida (`config.yml`)

```yaml
# ítems que el jugador puede comprar (listos para editar)
items:
  sword:
    material: DIAMOND_SWORD
    name: "&bEspada del Vacío"
    price: 500          # precio en moneda del servidor
    permission: surgir.entregas.roles.vip   # opcional: dejar vacío para todos
    command: give %player% diamond_sword 1
  bread:
    material: BREAD
    name: "Pan"
    price: 5
    command: give %player% bread 4
```

Cada ítem puede ejecutar cualquier comando al comprarse (`%player%` se reemplaza
por el jugador). Así puedes vender items, kits, monedas y más sin escribir código.

## Estructura del paquete

```text
SurgirEntregas/
  plugin.yml            Metadatos del plugin
  config.yml            Configuración editable
  README.md             Este archivo
  src/main/java/co/surgir/entregas/   Código fuente de la demo
```

## Soporte

- Discord de SURGIR: próximamente.
- Repositorio y documentación: próximamente.

© SURGIR — Tecnología, Plugins y Desarrollo.