package co.surgir.entregas;

import org.bukkit.plugin.java.JavaPlugin;

/**
 * SurgirEntregas — plugin de prueba de SURGIR.
 *
 * Demo minima que carga la configuracion (config.yml), registra el comando
 * /entrega y deja preparada la venta de items y las entregas entre jugadores.
 */
public final class SurgirEntregas extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadConfig();

        // El comando real se registra desde plugin.yml.
        getCommand("entrega").setExecutor(new EntregaCommand(this));

        getLogger().info("SurgirEntregas v" + getDescription().getVersion() + " activado.");
    }

    @Override
    public void onDisable() {
        getLogger().info("SurgirEntregas desactivado.");
    }
}