package co.surgir.entregas;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

/** Comando /entrega: help, shop, buy y reload. */
public final class EntregaCommand implements CommandExecutor {

    private final SurgirEntregas plugin;

    public EntregaCommand(SurgirEntregas plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String action = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "help";

        switch (action) {
            case "reload":
                if (!sender.hasPermission("surgir.entregas.admin")) {
                    sender.sendMessage(msg("messages.no-permission"));
                    return true;
                }
                plugin.reloadConfig();
                sender.sendMessage(msg("messages.reloaded"));
                return true;

            case "buy":
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(msg("messages.no-permission"));
                    return true;
                }
                if (!player.hasPermission("surgir.entregas.buy")) {
                    player.sendMessage(msg("messages.no-permission"));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(msg("messages.invalid-item"));
                    return true;
                }
                buyItem(player, args[1]);
                return true;

            case "shop":
                sender.sendMessage("&8&m-----------------------------");
                sender.sendMessage("&b&lTienda de Entregas (prueba)");
                for (String key : itemKeys()) {
                    sender.sendMessage("  &f" + key + " &7- &b" + price(key) + " " + currency());
                }
                sender.sendMessage("&8&m-----------------------------");
                return true;

            case "help":
            default:
                sender.sendMessage("&bSurgirEntregas &7v" + plugin.getDescription().getVersion());
                sender.sendMessage("  &f/entrega shop &7- ver tienda");
                sender.sendMessage("  &f/entrega buy <id> &7- comprar item");
                sender.sendMessage("  &f/entrega reload &7- recargar config (admin)");
                return true;
        }
    }

    private void buyItem(Player player, String id) {
        String cmd = plugin.getConfig().getString("items." + id + ".command", "");
        if (cmd.isEmpty()) {
            player.sendMessage(msg("messages.invalid-item"));
            return;
        }
        // En la demo se simula la compra ejecutando el comando del item.
        String name = plugin.getConfig().getString("items." + id + ".name", id);
        int price = plugin.getConfig().getInt("items." + id + ".price", 0);
        player.getServer().dispatchCommand(
                plugin.getServer().getConsoleSender(),
                cmd.replace("%player%", player.getName())
        );
        player.sendMessage(msg("messages.item-bought")
                .replace("%item%", name)
                .replace("%price%", String.valueOf(price))
                .replace("%currency%", currency()));
    }

    private List<String> itemKeys() {
        return List.copyOf(plugin.getConfig().getConfigurationSection("items").getKeys(false));
    }

    private int price(String key) {
        return plugin.getConfig().getInt("items." + key + ".price", 0);
    }

    private String currency() {
        return plugin.getConfig().getString("currency-name", "monedas");
    }

    private String msg(String path) {
        return plugin.getConfig().getString(path, "")
                .replace("&", "\u00a7");
    }
}